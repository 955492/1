USE_CUDA = True
DATA_PARALLEL = True
RANDOM_SEED = 514
LR = 0.04
CKPT_PER_ITER = 40
EPOCHS = 300
BS = 128
RSLT_DIR = "results"
LABELS = ["AntiGramn", "AntiGramp", "Antiviral", "Antifungal", "Anticancer", "Antimammal", "Antiparasite"]
# LABELS = "AMP"

## Asymmetric Loss configs
ASL_CONFIG_SINGLE = {'gamma_neg':2, 'eps':0.1}
ASL_CONFIG_MULTIL = {'gamma_neg':4, 'gamma_pos':1, 'clip':0.064}


model_presets = {'linsize': 640, 'pretrained': True, 'bert_frozen': True, 'lindropout': 0.2}
