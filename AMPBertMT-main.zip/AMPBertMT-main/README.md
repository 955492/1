# AMPBertMT

A Bert-based self-supervised antimicrobial peptide identification and functional prediction.

## Requirements

Download the conda environment `AMPBertMT` by executing the following commands.

```(shell)
conda create -f env.yaml
```

Then, enter the environment with:

```(shell)
conda activate AMPBertMT
```

Moreover, to update the environment (just in case), execute:

```(shell)
conda env update --name AMPBertMT --file env.yaml
```

## Identification: train and evaluate the first-stage model

for example, you can execute the following command.

```(shell)
python train.py --epochs 100 --ckpt-iter 15 --seed 514 --lr 0.032 --cuda True
```

Then, a specified result directory `result/[RSLT_DIR]/` will be created. by checking the specific name of the directory, you can perform the evaluation through the following command:

```(shell)
python evaluate.py --path "result/[RSLT_DIR]" --cuda True
```

For both the training and evaluation, you may specifying the data parallel status at python codes. You can check more details about the training/evaluation parameters though `train.py` or `evaluate.py`.
